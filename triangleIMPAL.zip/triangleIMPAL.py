a = int (input("masukkan nilai sisi 1 = "))
b = int (input("masukkan nilai sisi 2 = "))
c = int (input("masukkan nilai sisi 3 = "))

if (a>0 and b>0 and c>0) :
	y=max(a,b,c)
	#while (y< ) :
	if (a==b and b==c) :
		print ("Segitiga Sama Sisi")
	elif (a==b or a==c or b==c) :
		print ("Segitiga Sama Kaki")
	elif (a**2+b**2==c**2 or a**2+c**2==b**2 or b**2+c**2==a**2) :
		print ("Segitiga Siku-siku")
	else :
		print ("Segitiga Bebas")